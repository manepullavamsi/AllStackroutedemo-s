import { Injectable } from '@angular/core';

@Injectable()
export class AuthenticationService {

  constructor() {

  }

  authenticateUser(data) {

  }

  setBearerToken(token) {

  }

  getBearerToken() {

  }

  isUserAuthenticated(token): Promise<boolean> {

  }
}
