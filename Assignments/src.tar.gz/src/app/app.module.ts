import { NgModule } from '@angular/core';

@NgModule({
  declarations: [ ],
  imports: [ ],
  providers: [ ],
  bootstrap: [ ],
  entryComponents: [ ]
})

export class AppModule { }
